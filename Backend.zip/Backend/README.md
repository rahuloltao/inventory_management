# Shop Inventory Management MERN Project

## Backend

Install packages

```bash
npm install
```
Run backend

```bash
npm start
```