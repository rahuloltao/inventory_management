# Shop Inventory Management MERN Project

## Frontend

Install packages

```bash
npm install
```
Run fronted

```bash
npm run dev
```

